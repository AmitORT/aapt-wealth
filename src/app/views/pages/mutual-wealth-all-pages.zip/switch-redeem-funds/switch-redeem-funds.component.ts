import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch-redeem-funds',
  templateUrl: './switch-redeem-funds.component.html',
  styleUrls: ['./switch-redeem-funds.component.css']
})
export class SwitchRedeemFundsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
