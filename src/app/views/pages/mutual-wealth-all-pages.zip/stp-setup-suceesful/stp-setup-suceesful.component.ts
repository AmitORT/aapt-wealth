import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stp-setup-suceesful',
  templateUrl: './stp-setup-suceesful.component.html',
  styleUrls: ['./stp-setup-suceesful.component.css']
})
export class StpSetupSuceesfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
