import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swp-setup-suceesful',
  templateUrl: './swp-setup-suceesful.component.html',
  styleUrls: ['./swp-setup-suceesful.component.css']
})
export class SwpSetupSuceesfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
