import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mutual-payment-successful',
  templateUrl: './mutual-payment-successful.component.html',
  styleUrls: ['./mutual-payment-successful.component.css']
})
export class MutualPaymentSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
