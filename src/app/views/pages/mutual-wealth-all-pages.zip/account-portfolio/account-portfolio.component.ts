import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-portfolio',
  templateUrl: './account-portfolio.component.html',
  styleUrls: ['./account-portfolio.component.css']
})
export class AccountPortfolioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
