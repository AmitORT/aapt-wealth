import { Component, OnInit } from '@angular/core';
import { Options } from '@angular-slider/ngx-slider';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/services/api/api.service';
import { AescryptoService } from 'src/app/services/cryptomanager/aescrypto.service';
import { ValidateService } from 'src/app/services/Validate/validate.service';
import { ToastrService } from 'ngx-toastr';

declare var $:any;


@Component({
  selector: 'app-mutual-create-goal',
  templateUrl: './mutual-create-goal.component.html',
  styleUrls: ['./mutual-create-goal.component.css']
})
export class MutualCreateGoalComponent implements OnInit {

  RupeeChange:boolean=false;
  // Monthly1:boolean=false;

 
  CreateGoal:any={
    "Payment_Mode":"",
    "Goal_Amount":"",
    "Goal_Duartion":"",
    "Installments":"",
    "Return_Rate":"2",
    "Inflation_Rate":"2",
    "Saving_Amount":""
  }

  DateOfInstallment:any;


  
  
  constructor(public route:Router,private toastr: ToastrService, public validate:ValidateService, private crypto:AescryptoService, private api:ApiService) { }

  ngOnInit(): void {

  } 

  getDateofInstallment(){   
    const d = new Date();
    console.log("d",d);
    console.log("this.DateOfInstallment",this.DateOfInstallment);
    let day = d.getDate();
    // alert(day);
    // this.CreateGoal.Installments = this.DateOfInstallment.getDate();
  }
  
  
 

  uploadFile($event:any) {
    var reader = new FileReader();
    reader.readAsDataURL($event.target.files[0]);
    reader.onload = function () {
    var ThumbnailBase64 = reader.result;
    console.log("thumbnail ",ThumbnailBase64);
    $("#profileimg").attr("src",ThumbnailBase64);
    }
    console.log($event.target.files[0]); // outputs the first file
    }

  options12: Options = {
    floor: 0,
    ceil: 20,
    hidePointerLabels:true,
    translate: (value12: number, label: any): string => {  
      switch (label) {  
          case label.Low:  
              return "<b>0% Min</b> ₹" + value12; 
          case label.High:  
              return "<b>20% Max</b> ₹" + value12;  
          default:  
              return value12 + "%" ;  
      }  
    }     
  };

  options13: Options = {
    floor: 0,
    ceil: 20,
    hidePointerLabels:true,
    translate: (value12: number, label: any): string => {  
      switch (label) {  
          case label.Low:  
              return "<b>0% Min</b> ₹" + value12; 
          case label.High:  
              return "<b>20% Max</b> ₹" + value12;  
          default:  
              return value12 + "%" ;  
      }  
    }     
  };

  CreateGoalAndInvest(){

    if(this.validate.isNullEmptyUndefined(this.CreateGoal.Payment_Mode)){
      this.toastr.error('Payment Mode is mandatory');
    }
    else if(this.validate.isNullEmptyUndefined(this.CreateGoal.Goal_Amount)){  this.validate.numberOnly(this.CreateGoal.Goal_Amount)
      this.toastr.error('Goal Amount is mandatory');
    }
    else if( this.validate.numberOnly(this.CreateGoal.Goal_Amount)){ 
      this.toastr.error('Goal Amount should be a number');
    }
    else if(this.validate.isNullEmptyUndefined(this.CreateGoal.Goal_Duartion)){
      this.toastr.error('Goal Duration is mandatory');
    }
    // else if(this.validate.isNullEmptyUndefined(this.CreateGoal.DateOfInstallment)){
    //   this.toastr.error('Date of Month is mandatory');
    // }
    // else if(this.validate.isNullEmptyUndefined(this.CreateGoal.Return_Rate)){
    //   this.toastr.error('Rate of Return is mandatory');
    // }
    // else if(this.validate.isNullEmptyUndefined(this.CreateGoal.Inflation_Rate)){
    //   this.toastr.error('Rate of Inflation is mandatory');
    // }
    else {
      this.route.navigate(['/mutual-fund-cart']);
    }

    
  }
  



}
