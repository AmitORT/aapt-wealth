import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fund-switch-suceesful',
  templateUrl: './fund-switch-suceesful.component.html',
  styleUrls: ['./fund-switch-suceesful.component.css']
})
export class FundSwitchSuceesfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
