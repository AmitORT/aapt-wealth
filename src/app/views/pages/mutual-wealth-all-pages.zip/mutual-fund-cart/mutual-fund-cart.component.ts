import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $:any;

@Component({
  selector: 'app-mutual-fund-cart',
  templateUrl: './mutual-fund-cart.component.html',
  styleUrls: ['./mutual-fund-cart.component.css']
})
export class MutualFundCartComponent implements OnInit {

  SelectedButton:boolean=false;
  SelectedButton1:boolean=false;
  SelectedButton2:boolean=false;
  SelectedButton3:boolean=false;
  SelectedButton4:boolean=false;
  ShowSelectedDetails:boolean=false;

  constructor(public route:Router) { }

  ngOnInit(): void {
  }

  CompareProduct(){
    $('#compare-products-modal').modal('hide');
    this.ShowSelectedDetails=true;
  }

  RedirectPopup(){
    $('#compare-products-modal').modal('hide');
    this.route.navigate(['/product-listing']);
  }

}
