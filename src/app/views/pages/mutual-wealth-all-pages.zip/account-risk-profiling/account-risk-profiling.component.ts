import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-risk-profiling',
  templateUrl: './account-risk-profiling.component.html',
  styleUrls: ['./account-risk-profiling.component.css']
})
export class AccountRiskProfilingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
