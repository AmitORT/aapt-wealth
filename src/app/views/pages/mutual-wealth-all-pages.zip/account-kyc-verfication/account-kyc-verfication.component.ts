import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-kyc-verfication',
  templateUrl: './account-kyc-verfication.component.html',
  styleUrls: ['./account-kyc-verfication.component.css']
})
export class AccountKycVerficationComponent implements OnInit {

 

  constructor() { }

  ngOnInit(): void {
  }

}
